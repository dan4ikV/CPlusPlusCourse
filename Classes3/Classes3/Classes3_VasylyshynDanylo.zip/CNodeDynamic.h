#pragma once
#include <vector>

using namespace std;

class CNodeDynamic
{
public:
	CNodeDynamic();
	CNodeDynamic(CNodeDynamic* root);
	~CNodeDynamic();
	void vSetValue(int iNewVal);
	int iGetChildrenNumber();
	void vAddNewChild();
	CNodeDynamic* pcGetChild(int iChildOffset);
	void vPrint();
	void vPrintAllBelow();
	void vPrintUp();
	CNodeDynamic* pcGetRoot();
	bool setChild(int num, CNodeDynamic* newChild);
	bool removeChild(CNodeDynamic* childNode);
	
private:
	vector<CNodeDynamic*> v_children;
	int i_val;
	CNodeDynamic* c_root;
};