#include <iostream>
#include <vector>
#include "CNodeStatic.h"
#include "CTreeStatic.h"
#include "CNodeDynamic.h"
#include "CTreeDynamic.h"
using namespace std;


void v_tree_test()
{
    cout << "testing with static tree" << endl;
    CNodeStatic c_root;
    c_root.vAddNewChild();
    c_root.vAddNewChild();
    c_root.pcGetChild(0)->vSetValue(1);
    c_root.pcGetChild(1)->vSetValue(2);
    c_root.pcGetChild(0)->vAddNewChild();
    c_root.pcGetChild(0)->vAddNewChild();
    c_root.pcGetChild(0)->pcGetChild(0)->vSetValue(11);
    c_root.pcGetChild(0)->pcGetChild(1)->vSetValue(12);
    c_root.pcGetChild(1)->vAddNewChild();
    c_root.pcGetChild(1)->vAddNewChild();
    c_root.pcGetChild(1)->pcGetChild(0)->vSetValue(21);
    c_root.pcGetChild(1)->pcGetChild(1)->vSetValue(22);
    c_root.vPrintAllBelow();
    cout << endl;
    c_root.pcGetChild(0)->pcGetChild(1)->vPrintUp();
    cout << endl;
    c_root.pcGetChild(1)->pcGetChild(0)->vPrintUp();
    cout << endl;

    CNodeStatic c_root_2;
    c_root_2.vAddNewChild();
    c_root_2.vAddNewChild();
    c_root_2.pcGetChild(0)->vSetValue(5);
    c_root_2.pcGetChild(1)->vSetValue(6);
    c_root_2.pcGetChild(0)->vAddNewChild();
    c_root_2.pcGetChild(0)->vAddNewChild();
    c_root_2.pcGetChild(0)->pcGetChild(0)->vSetValue(7);
    c_root_2.pcGetChild(0)->pcGetChild(1)->vSetValue(8);
    c_root_2.pcGetChild(1)->vAddNewChild();
    c_root_2.pcGetChild(1)->vAddNewChild();
    c_root_2.pcGetChild(1)->pcGetChild(0)->vSetValue(9);
    c_root_2.pcGetChild(1)->pcGetChild(1)->vSetValue(10);

    CTreeStatic tree(&c_root);
    tree.bMoveSubtree(tree.pcGetRoot()->pcGetChild(0)->pcGetChild(0), c_root_2.pcGetChild(0), c_root_2.pcGetChild(0)->pcGetRoot());
    tree.vPrintTree();
    cout << endl;
    c_root_2.vPrintAllBelow();

}

void v_dynamic_tree_test()
{
    cout << "testing with dynamic tree" << endl;
    CNodeDynamic c_root;
    c_root.vAddNewChild();
    c_root.vAddNewChild();
    c_root.pcGetChild(0)->vSetValue(1);
    c_root.pcGetChild(1)->vSetValue(2);
    c_root.pcGetChild(0)->vAddNewChild();
    c_root.pcGetChild(0)->vAddNewChild();
    c_root.pcGetChild(0)->pcGetChild(0)->vSetValue(11);
    c_root.pcGetChild(0)->pcGetChild(1)->vSetValue(12);
    c_root.pcGetChild(1)->vAddNewChild();
    c_root.pcGetChild(1)->vAddNewChild();
    c_root.pcGetChild(1)->pcGetChild(0)->vSetValue(21);
    c_root.pcGetChild(1)->pcGetChild(1)->vSetValue(22);
    c_root.vPrintAllBelow();
    cout << endl;
    c_root.pcGetChild(0)->pcGetChild(1)->vPrintUp();
    cout << endl;
    c_root.pcGetChild(1)->pcGetChild(0)->vPrintUp();


    CNodeDynamic c_root_2;
    c_root_2.vAddNewChild();
    c_root_2.vAddNewChild();
    c_root_2.pcGetChild(0)->vSetValue(5);
    c_root_2.pcGetChild(1)->vSetValue(6);
    c_root_2.pcGetChild(0)->vAddNewChild();
    c_root_2.pcGetChild(0)->vAddNewChild();
    c_root_2.pcGetChild(0)->pcGetChild(0)->vSetValue(7);
    c_root_2.pcGetChild(0)->pcGetChild(1)->vSetValue(8);
    c_root_2.pcGetChild(1)->vAddNewChild();
    c_root_2.pcGetChild(1)->vAddNewChild();
    c_root_2.pcGetChild(1)->pcGetChild(0)->vSetValue(9);
    c_root_2.pcGetChild(1)->pcGetChild(1)->vSetValue(10);

    CTreeDynamic tree(&c_root);
    tree.bMoveSubtree(c_root.pcGetChild(0)->pcGetChild(0), c_root_2.pcGetChild(0) , c_root_2.pcGetChild(0)->pcGetRoot());
    cout << endl;
    tree.vPrintTree();
    cout << endl;
    c_root_2.vPrintAllBelow();
}

int main()
{
    v_tree_test();
    cout << endl << endl;
    v_dynamic_tree_test();
}