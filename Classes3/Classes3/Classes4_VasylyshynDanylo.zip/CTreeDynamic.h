#pragma once
#include "CNodeDynamic.h" 

template <typename T> class CTreeDynamic
{
private:
    CNodeDynamic<T>* c_root;
public:
    CTreeDynamic() { c_root = new CNodeDynamic<T>(); };
    CTreeDynamic(CNodeDynamic<T>* root) { c_root = root; };
    ~CTreeDynamic() {};
    CNodeDynamic<T>* pcGetRoot() { return c_root;  };
    void vPrintTree() { c_root->vPrintAllBelow; };
    void bMoveSubtree(CNodeDynamic<T>* pcParentNode, CNodeDynamic<T>* pcNewChildNode, CNodeDynamic<T>* pc2ParentNode) {
        pcParentNode->vAddNewChild();
        pcParentNode->setChild(pcParentNode->iGetChildrenNumber() - 1, pcNewChildNode);
        if (pc2ParentNode != NULL) {
            pc2ParentNode->removeChild(pcNewChildNode);
        }
    };
    int countOccurences(int val) {
        return pcGetRoot()->count(val);
    };

};

