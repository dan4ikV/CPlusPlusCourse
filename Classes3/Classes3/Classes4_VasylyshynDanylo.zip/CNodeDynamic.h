#pragma once
#include <vector>

using namespace std;

template <typename T> class CNodeDynamic
{
private:
    vector<CNodeDynamic<T>*> v_children;
    T i_val;
    CNodeDynamic<T>* c_root;

public:

    CNodeDynamic() { };

    CNodeDynamic(CNodeDynamic<T>* root) {
        c_root = root;
    };

    ~CNodeDynamic() {
        for (int i = 0; i < iGetChildrenNumber(); i++) {
            (*pcGetChild(i)).~CNodeDynamic();
        }
    };

    void vSetValue(T iNewVal) { i_val = iNewVal; };

    int iGetChildrenNumber() { return(v_children.size()); };

    void vAddNewChild() { v_children.push_back(new CNodeDynamic<T>(this)); }

    CNodeDynamic<T>* pcGetChild(int iChildOffset) {
        if (iChildOffset < v_children.size() && iChildOffset >= 0) {
            return v_children.at(iChildOffset);
        }
        else {
            return NULL;
        }
    }

    void vPrint() { cout << " " << i_val; };

    void vPrintAllBelow() {
        vPrint();
        for (int i = 0; i < iGetChildrenNumber(); i++) {
            (*pcGetChild(i)).vPrintAllBelow();
        }
    }

    void vPrintUp() {
        vPrint();
        if (!c_root == NULL) {
            c_root->vPrintUp();
        }
    }

    CNodeDynamic<T>* pcGetRoot() { return(c_root); }

    bool setChild(int num, CNodeDynamic<T>* newChild) {
        if (num >= 0 && num < iGetChildrenNumber()) {
            v_children.at(num) = newChild;
            return true;
        }
        else {
            return false;
        }
    }

    bool removeChild(CNodeDynamic<T>* childNode) {
        for (int i = 0; i < iGetChildrenNumber(); i++) {
            if (childNode == v_children.at(i)) {
                v_children.erase(v_children.begin() + i);
                return true;
            }
        }
        return false;
    }

    int count(int val) {
        int found = 0;
        for (int i = 0; i < iGetChildrenNumber(); i++) {
            found += v_children.at(i)->count(val);
        }
        if (i_val == val) {
            return found + 1;
        }
        return found;
    }
};