/*#include <iostream>
#include <vector>
#include "CNodeDynamic.h"

using namespace std;


template <typename T>
CNodeDynamic<T>::CNodeDynamic() { i_val = 0; };

template <typename T>
CNodeDynamic<T>::CNodeDynamic(CNodeDynamic* root) {
    i_val = 0;
    c_root = root;
};
template <typename T>
CNodeDynamic<T>::~CNodeDynamic() {
    for (int i = 0; i < iGetChildrenNumber(); i++) {
        (*pcGetChild(i)).~CNodeDynamic();
    }
};

template <typename T>
void CNodeDynamic<T>::vSetValue(int iNewVal) { i_val = iNewVal; };

template <typename T>
int CNodeDynamic<T>::iGetChildrenNumber() { return(v_children.size()); };

template <typename T>
void CNodeDynamic<T>::vAddNewChild() { v_children.push_back(new CNodeDynamic(this)); }

template <typename T>
CNodeDynamic<T>* CNodeDynamic<T>::pcGetChild(int iChildOffset) {
    if (iChildOffset < v_children.size() && iChildOffset >= 0) {
        return v_children.at(iChildOffset);
    }
    else {
        return NULL;
    }
}

template <typename T>
void CNodeDynamic<T>::vPrint() { cout << " " << i_val; };

template <typename T>
void CNodeDynamic<T>::vPrintAllBelow() {
    vPrint();
    for (int i = 0; i < iGetChildrenNumber(); i++) {
        (*pcGetChild(i)).vPrintAllBelow();
    }
}

template <typename T>
void CNodeDynamic<T>::vPrintUp() {
    vPrint();
    if (!c_root == NULL) {
        c_root->vPrintUp();
    }
}

template <typename T>
CNodeDynamic<T>* CNodeDynamic<T>::pcGetRoot() { return(c_root); }

template <typename T>
bool CNodeDynamic<T>::setChild(int num, CNodeDynamic* newChild) {
    if (num >= 0 && num < iGetChildrenNumber()) {
        v_children.at(num) = newChild;
        return true;
    }
    else {
        return false;
    }
}

template <typename T>
bool CNodeDynamic<T>::removeChild(CNodeDynamic* childNode) {
    for (int i = 0; i < iGetChildrenNumber(); i++) {
        if (childNode == v_children.at(i)) {
            v_children.erase(v_children.begin() + i);
            return true;
        }
    }
    return false;
}

template <typename T>
int CNodeDynamic<T>::count(int val) {
    int found = 0;
    for (int i = 0; i < iGetChildrenNumber(); i++) {
        found += v_children.at(i)->count(val);
    }
    if (i_val == val) {
        return found + 1;
    }
    return found;
}*/