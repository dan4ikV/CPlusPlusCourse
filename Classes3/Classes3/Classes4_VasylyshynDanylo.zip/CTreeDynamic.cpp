/*#include "CTreeDynamic.h"
using namespace std;

template <typename T>
CTreeDynamic<T>::CTreeDynamic() { c_root = new CNodeDynamic<T>(); };
template <typename T>
CTreeDynamic<T>::CTreeDynamic<T>(CNodeDynamic<T>* root) { c_root = root; };

template <typename T>
CTreeDynamic<T>::~CTreeDynamic<T>() {};

template <typename T>
CNodeDynamic<T>* CTreeDynamic<T>::pcGetRoot() { return(c_root); }

template <typename T>
void CTreeDynamic<T>::vPrintTree() { c_root->vPrintAllBelow(); };

template <typename T>
void CTreeDynamic<T>::bMoveSubtree(CNodeDynamic<T>* pcParentNode, CNodeDynamic<T>* pcNewChildNode, CNodeDynamic<T>* pc2ParentNode) {
	pcParentNode->vAddNewChild();
	pcParentNode->setChild(pcParentNode->iGetChildrenNumber() - 1, pcNewChildNode);
	if (pc2ParentNode != NULL) {
		pc2ParentNode->removeChild(pcNewChildNode);
	}
}

template <typename T>
int CTreeDynamic<T>::countOccurences(int val) {
	return pcGetRoot()->count(val);
}*/